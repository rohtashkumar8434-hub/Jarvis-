package com.jarvis.pc.pc

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.jarvis.pc.R
import com.jarvis.pc.automation.AutoTouchController
import com.jarvis.pc.core.DeviceModeManager
import com.jarvis.pc.jarvis.ActionExecutor
import com.jarvis.pc.jarvis.JarvisBrain
import com.jarvis.pc.jarvis.VoiceManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class PcModeActivity : AppCompatActivity() {

    private lateinit var rotationLockManager: RotationLockManager
    private lateinit var deviceModeManager: DeviceModeManager
    private lateinit var jarvisBrain: JarvisBrain
    private lateinit var actionExecutor: ActionExecutor
    private lateinit var voiceManager: VoiceManager

    private lateinit var tvClock: TextView
    private lateinit var etTaskbarAskJarvis: EditText
    private lateinit var btnStartMenu: ImageButton
    private lateinit var startMenuContainer: FrameLayout

    private val timeHandler = Handler(Looper.getMainLooper())
    private val timeRunnable = object : Runnable {
        override fun run() {
            val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
            tvClock.text = sdf.format(Date())
            timeHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pc_mode)

        rotationLockManager = RotationLockManager(this)
        rotationLockManager.lockToLandscape()

        deviceModeManager = DeviceModeManager(this) { isPcMode ->
            if (!isPcMode) finish()
        }
        deviceModeManager.startListening()

        jarvisBrain = JarvisBrain(this)
        actionExecutor = ActionExecutor(this)
        voiceManager = VoiceManager(this, onSpeechRecognized = { speech ->
            etTaskbarAskJarvis.setText(speech)
            handleJarvisQuery(speech)
        }, onListeningState = {})

        initViews()
    }

    private fun initViews() {
        tvClock = findViewById(R.id.tvTaskbarClock)
        etTaskbarAskJarvis = findViewById(R.id.etTaskbarAskJarvis)
        btnStartMenu = findViewById(R.id.btnStartMenu)
        startMenuContainer = findViewById(R.id.startMenuContainer)

        timeHandler.post(timeRunnable)

        btnStartMenu.setOnClickListener { toggleStartMenu() }
        findViewById<ImageButton>(R.id.btnTaskbarMic).setOnClickListener { voiceManager.startListening() }

        etTaskbarAskJarvis.setOnEditorActionListener { _, _, _ ->
            val query = etTaskbarAskJarvis.text.toString().trim()
            if (query.isNotBlank()) handleJarvisQuery(query)
            true
        }

        findViewById<View>(R.id.iconBrowser).setOnClickListener {
            FreeformLauncher.launch(this, "com.android.chrome")
        }
        findViewById<View>(R.id.iconFiles).setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                type = "*/*"
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try { startActivity(intent) } catch (_: Exception) {}
        }
        findViewById<View>(R.id.iconYouTube).setOnClickListener {
            FreeformLauncher.launch(this, "com.google.android.youtube")
        }
        findViewById<View>(R.id.iconSettings).setOnClickListener {
            FreeformLauncher.launch(this, "com.android.settings")
        }

        findViewById<Button>(R.id.btnDesktopAutoTouch).setOnClickListener {
            val metrics = resources.displayMetrics
            AutoTouchController.tap(metrics.widthPixels / 2f, metrics.heightPixels / 2f) { success ->
                val msg = if (success) "Auto Touch executed successfully!" else "Accessibility service inactive!"
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun toggleStartMenu() {
        if (startMenuContainer.visibility == View.VISIBLE) {
            startMenuContainer.visibility = View.GONE
        } else {
            showStartMenu()
        }
    }

    private fun showStartMenu() {
        startMenuContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        val menuView = inflater.inflate(R.layout.view_start_menu, startMenuContainer, false)

        val gridApps = menuView.findViewById<GridLayout>(R.id.gridInstalledApps)
        loadInstalledAppsIntoGrid(gridApps)

        menuView.findViewById<Button>(R.id.btnSwitchToJarvis).setOnClickListener {
            startMenuContainer.visibility = View.GONE
            finish()
        }

        startMenuContainer.addView(menuView)
        startMenuContainer.visibility = View.VISIBLE
    }

    private fun loadInstalledAppsIntoGrid(grid: GridLayout) {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = pm.queryIntentActivities(intent, 0).take(12)

        for (resolveInfo in apps) {
            val appBtn = Button(this).apply {
                text = resolveInfo.loadLabel(pm).toString()
                textSize = 12f
                setOnClickListener {
                    startMenuContainer.visibility = View.GONE
                    FreeformLauncher.launch(this@PcModeActivity, resolveInfo.activityInfo.packageName)
                }
            }
            grid.addView(appBtn)
        }
    }

    private fun handleJarvisQuery(query: String) {
        lifecycleScope.launch {
            Toast.makeText(this@PcModeActivity, "Jarvis: Processing '$query'...", Toast.LENGTH_SHORT).show()
            val result = jarvisBrain.processQuery(query)
            actionExecutor.execute(result)
            voiceManager.speak(result.spokenResponse)
            Toast.makeText(this@PcModeActivity, result.spokenResponse, Toast.LENGTH_LONG).show()
            etTaskbarAskJarvis.text.clear()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        timeHandler.removeCallbacks(timeRunnable)
        rotationLockManager.unlockRotation()
        deviceModeManager.stopListening()
        voiceManager.destroy()
    }
}
