package com.jarvis.pc.jarvis

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.Settings
import android.widget.Toast
import com.jarvis.pc.automation.AutoTouchController
import com.jarvis.pc.pc.PcModeActivity

class ActionExecutor(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun execute(result: JarvisCommandResult) {
        when (result.action) {
            "HOME" -> AutoTouchController.performHome()
            "BACK" -> AutoTouchController.performBack()
            "RECENTS" -> AutoTouchController.performRecents()
            "SCREENSHOT" -> AutoTouchController.takeScreenshot()
            "NOTIFICATIONS" -> AutoTouchController.performNotifications()

            "SCROLL_DOWN" -> {
                val dm = context.resources.displayMetrics
                AutoTouchController.scrollDown(dm.widthPixels, dm.heightPixels)
            }
            "SCROLL_UP" -> {
                val dm = context.resources.displayMetrics
                AutoTouchController.scrollUp(dm.widthPixels, dm.heightPixels)
            }
            "AUTO_TOUCH_TEXT" -> {
                val target = result.params["target"] ?: ""
                if (target.isNotBlank()) {
                    val clicked = AutoTouchController.clickByText(target)
                    if (!clicked) {
                        Toast.makeText(context, "Could not find '$target' on active screen", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            "TORCH_ON" -> setTorch(true)
            "TORCH_OFF" -> setTorch(false)

            "VOLUME_UP" -> audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "VOLUME_DOWN" -> audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "MUTE" -> audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)

            "OPEN_APP" -> {
                val pkg = result.params["pkg"]
                val appName = result.params["appName"] ?: result.params["target"] ?: ""
                launchApp(pkg, appName)
            }

            "WEB_SEARCH" -> {
                val q = result.params["query"] ?: result.params["target"] ?: ""
                val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                    putExtra(SearchManager.QUERY, q)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }

            "SWITCH_PC_MODE" -> {
                val intent = Intent(context, PcModeActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                context.startActivity(intent)
            }
        }
    }

    private fun setTorch(enable: Boolean) {
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList[0]
            cm.setTorchMode(id, enable)
        } catch (e: Exception) {
            Toast.makeText(context, "Torch error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchApp(pkg: String?, query: String) {
        val pm = context.packageManager
        var intent: Intent? = null
        if (!pkg.isNullOrBlank()) {
            intent = pm.getLaunchIntentForPackage(pkg)
        }
        if (intent == null && query.isNotBlank()) {
            val apps = pm.getInstalledApplications(0)
            for (app in apps) {
                if (pm.getApplicationLabel(app).toString().lowercase().contains(query.lowercase())) {
                    intent = pm.getLaunchIntentForPackage(app.packageName)
                    break
                }
            }
        }
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } else {
            Toast.makeText(context, "Application '$query' not found", Toast.LENGTH_SHORT).show()
        }
    }
}
