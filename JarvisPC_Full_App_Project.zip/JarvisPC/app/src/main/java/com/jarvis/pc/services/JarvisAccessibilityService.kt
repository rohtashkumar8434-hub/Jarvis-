package com.jarvis.pc.services

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.jarvis.pc.pc.PcModeActivity

/**
 * Handles global keyboard shortcuts and gesture dispatching.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        var instance: JarvisAccessibilityService? = null
            private set
    }

    private var metaPressed = false
    private var altPressed = false
    private var ctrlPressed = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val action = event.action

        when (keyCode) {
            KeyEvent.KEYCODE_META_LEFT, KeyEvent.KEYCODE_META_RIGHT -> {
                metaPressed = (action == KeyEvent.ACTION_DOWN)
            }
            KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_ALT_RIGHT -> {
                altPressed = (action == KeyEvent.ACTION_DOWN)
            }
            KeyEvent.KEYCODE_CTRL_LEFT, KeyEvent.KEYCODE_CTRL_RIGHT -> {
                ctrlPressed = (action == KeyEvent.ACTION_DOWN)
            }
        }

        if (action == KeyEvent.ACTION_DOWN) {
            if (metaPressed) {
                when (keyCode) {
                    KeyEvent.KEYCODE_D -> {
                        performGlobalAction(GLOBAL_ACTION_HOME)
                        return true
                    }
                    KeyEvent.KEYCODE_E -> {
                        launchFileManager()
                        return true
                    }
                    KeyEvent.KEYCODE_R -> {
                        launchJarvisPrompt()
                        return true
                    }
                }
            }

            if (altPressed && keyCode == KeyEvent.KEYCODE_TAB) {
                performGlobalAction(GLOBAL_ACTION_RECENTS)
                return true
            }

            if (ctrlPressed && altPressed && keyCode == KeyEvent.KEYCODE_T) {
                val intent = Intent(this, PcModeActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(intent)
                return true
            }
        }

        return super.onKeyEvent(event)
    }

    private fun launchFileManager() {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            type = "*/*"
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    private fun launchJarvisPrompt() {
        val intent = Intent(this, com.jarvis.pc.jarvis.JarvisModeActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("EXTRA_START_VOICE", true)
        }
        startActivity(intent)
    }
}
