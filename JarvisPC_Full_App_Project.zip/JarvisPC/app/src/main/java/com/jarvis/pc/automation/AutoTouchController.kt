package com.jarvis.pc.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvis.pc.services.JarvisAccessibilityService

/**
 * Advanced Automatic Touch Control & Gesture Automation.
 * Simulates real finger touch gestures on screen: tap, swipe, scroll, click by text.
 */
object AutoTouchController {

    private val service: JarvisAccessibilityService?
        get() = JarvisAccessibilityService.instance

    fun isServiceActive(): Boolean = service != null

    fun tap(x: Float, y: Float, durationMs: Long = 80, onComplete: ((Boolean) -> Unit)? = null) {
        val s = service ?: run {
            onComplete?.invoke(false)
            return
        }

        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        s.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onComplete?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                onComplete?.invoke(false)
            }
        }, null)
    }

    fun swipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 300, onComplete: ((Boolean) -> Unit)? = null) {
        val s = service ?: run {
            onComplete?.invoke(false)
            return
        }

        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        s.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onComplete?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                onComplete?.invoke(false)
            }
        }, null)
    }

    fun scrollDown(screenWidth: Int, screenHeight: Int, onComplete: ((Boolean) -> Unit)? = null) {
        val midX = screenWidth / 2f
        val startY = screenHeight * 0.75f
        val endY = screenHeight * 0.25f
        swipe(midX, startY, midX, endY, 250, onComplete)
    }

    fun scrollUp(screenWidth: Int, screenHeight: Int, onComplete: ((Boolean) -> Unit)? = null) {
        val midX = screenWidth / 2f
        val startY = screenHeight * 0.25f
        val endY = screenHeight * 0.75f
        swipe(midX, startY, midX, endY, 250, onComplete)
    }

    fun clickByText(text: String): Boolean {
        val s = service ?: return false
        val rootNode = s.rootInActiveWindow ?: return false

        val nodes = rootNode.findAccessibilityNodeInfosByText(text)
        if (!nodes.isNullOrEmpty()) {
            for (node in nodes) {
                if (node.isClickable) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return true
                } else {
                    var parent = node.parent
                    while (parent != null) {
                        if (parent.isClickable) {
                            parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                            return true
                        }
                        parent = parent.parent
                    }
                }
                val rect = Rect()
                node.getBoundsInScreen(rect)
                if (!rect.isEmpty) {
                    tap(rect.centerX().toFloat(), rect.centerY().toFloat())
                    return true
                }
            }
        }
        return false
    }

    fun performBack(): Boolean = service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) ?: false
    fun performHome(): Boolean = service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) ?: false
    fun performRecents(): Boolean = service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS) ?: false
    fun performNotifications(): Boolean = service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) ?: false
    fun performQuickSettings(): Boolean = service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) ?: false
    fun takeScreenshot(): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        service?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) ?: false
    } else false
}
