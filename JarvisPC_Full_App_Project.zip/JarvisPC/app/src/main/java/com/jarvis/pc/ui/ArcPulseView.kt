package com.jarvis.pc.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator

class ArcPulseView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val cyanPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3300E5FF")
        style = Paint.Style.STROKE
        strokeWidth = 14f
    }

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8000E5FF")
        style = Paint.Style.FILL
    }

    private var rotationAngle = 0f
    private var pulseScale = 1.0f

    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 4000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            rotationAngle = it.animatedValue as Float
            invalidate()
        }
    }

    private val pulseAnimator = ValueAnimator.ofFloat(0.85f, 1.25f).apply {
        duration = 800
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.REVERSE
        addUpdateListener {
            pulseScale = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        animator.start()
    }

    fun setListening(listening: Boolean) {
        if (listening) {
            cyanPaint.color = Color.parseColor("#FF9100")
            glowPaint.color = Color.parseColor("#44FF9100")
            corePaint.color = Color.parseColor("#99FF9100")
            pulseAnimator.start()
        } else {
            cyanPaint.color = Color.parseColor("#00E5FF")
            glowPaint.color = Color.parseColor("#3300E5FF")
            corePaint.color = Color.parseColor("#8000E5FF")
            pulseAnimator.cancel()
            pulseScale = 1.0f
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = (Math.min(width, height) / 2f) * 0.75f

        canvas.drawCircle(cx, cy, (radius * 0.28f) * pulseScale, corePaint)

        val rectOuter = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        canvas.save()
        canvas.rotate(rotationAngle, cx, cy)
        canvas.drawArc(rectOuter, 0f, 75f, false, glowPaint)
        canvas.drawArc(rectOuter, 0f, 75f, false, cyanPaint)
        canvas.drawArc(rectOuter, 120f, 75f, false, glowPaint)
        canvas.drawArc(rectOuter, 120f, 75f, false, cyanPaint)
        canvas.drawArc(rectOuter, 240f, 75f, false, glowPaint)
        canvas.drawArc(rectOuter, 240f, 75f, false, cyanPaint)
        canvas.restore()

        val innerRadius = radius * 0.6f
        val rectInner = RectF(cx - innerRadius, cy - innerRadius, cx + innerRadius, cy + innerRadius)
        canvas.save()
        canvas.rotate(-rotationAngle * 1.5f, cx, cy)
        canvas.drawArc(rectInner, 45f, 90f, false, cyanPaint)
        canvas.drawArc(rectInner, 225f, 90f, false, cyanPaint)
        canvas.restore()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        animator.cancel()
        pulseAnimator.cancel()
    }
}
