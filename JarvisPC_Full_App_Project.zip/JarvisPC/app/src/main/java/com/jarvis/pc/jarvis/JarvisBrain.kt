package com.jarvis.pc.jarvis

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

data class JarvisCommandResult(
    val action: String,
    val params: Map<String, String> = emptyMap(),
    val spokenResponse: String,
    val isOfflineExecuted: Boolean = false
)

class JarvisBrain(private val context: Context, private var apiKey: String = "") {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    fun setApiKey(key: String) {
        apiKey = key
    }

    suspend fun processQuery(userSpeech: String): JarvisCommandResult = withContext(Dispatchers.IO) {
        val clean = userSpeech.trim().lowercase()

        // 1. Fast Offline Pattern Matching Engine
        val offline = parseOfflineCommand(clean)
        if (offline != null) {
            return@withContext offline
        }

        // 2. Online Engine with Gemini / OpenAI API
        if (isNetworkAvailable() && apiKey.isNotBlank()) {
            try {
                return@withContext executeOnlineAi(userSpeech)
            } catch (e: Exception) {
                return@withContext JarvisCommandResult(
                    action = "SPEAK_ONLY",
                    spokenResponse = "Sir, online service encountered a connection latency. Reverting to offline protocol.",
                    isOfflineExecuted = true
                )
            }
        }

        // 3. Smart Offline Fallback
        JarvisCommandResult(
            action = "SPEAK_ONLY",
            spokenResponse = "Sir, that command is not cached offline. You can ask me to open apps, toggle torch, scroll, or switch to PC mode.",
            isOfflineExecuted = true
        )
    }

    private fun parseOfflineCommand(cleanText: String): JarvisCommandResult? {
        // Navigation
        if (cleanText.contains("go home") || cleanText.contains("home screen") || cleanText == "home") {
            return JarvisCommandResult("HOME", emptyMap(), "Navigating to Home screen, Sir.", true)
        }
        if (cleanText.contains("go back") || cleanText == "back") {
            return JarvisCommandResult("BACK", emptyMap(), "Going back, Sir.", true)
        }
        if (cleanText.contains("recent apps") || cleanText.contains("recents")) {
            return JarvisCommandResult("RECENTS", emptyMap(), "Opening task overview.", true)
        }
        if (cleanText.contains("screenshot")) {
            return JarvisCommandResult("SCREENSHOT", emptyMap(), "Capturing screenshot now.", true)
        }
        if (cleanText.contains("notification")) {
            return JarvisCommandResult("NOTIFICATIONS", emptyMap(), "Displaying notifications.", true)
        }

        // Automatic Touch Gestures
        if (cleanText.contains("scroll down") || cleanText.contains("niche scroll")) {
            return JarvisCommandResult("SCROLL_DOWN", emptyMap(), "Auto-scrolling downward.", true)
        }
        if (cleanText.contains("scroll up") || cleanText.contains("upar scroll")) {
            return JarvisCommandResult("SCROLL_UP", emptyMap(), "Auto-scrolling upward.", true)
        }
        if (cleanText.startsWith("click ") || cleanText.startsWith("tap ") || cleanText.startsWith("touch ")) {
            val target = cleanText.substringAfter(" ").trim()
            return JarvisCommandResult("AUTO_TOUCH_TEXT", mapOf("target" to target), "Executing automatic tap on $target.", true)
        }

        // Flashlight & Media
        if (cleanText.contains("torch on") || cleanText.contains("flashlight on")) {
            return JarvisCommandResult("TORCH_ON", emptyMap(), "Illumination protocol engaged.", true)
        }
        if (cleanText.contains("torch off") || cleanText.contains("flashlight off")) {
            return JarvisCommandResult("TORCH_OFF", emptyMap(), "Flashlight deactivated.", true)
        }
        if (cleanText.contains("volume up") || cleanText.contains("awaz badhao")) {
            return JarvisCommandResult("VOLUME_UP", emptyMap(), "Increasing audio volume.", true)
        }
        if (cleanText.contains("volume down") || cleanText.contains("awaz kam karo")) {
            return JarvisCommandResult("VOLUME_DOWN", emptyMap(), "Decreasing volume level.", true)
        }
        if (cleanText.contains("mute") || cleanText.contains("silent")) {
            return JarvisCommandResult("MUTE", emptyMap(), "Audio muted, Sir.", true)
        }

        // App Launching
        val apps = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "camera" to "camera",
            "chrome" to "com.android.chrome",
            "settings" to "com.android.settings"
        )
        for ((name, pkg) in apps) {
            if (cleanText.contains("open $name") || cleanText.contains("launch $name") || cleanText.contains("$name kholo")) {
                return JarvisCommandResult("OPEN_APP", mapOf("appName" to name, "pkg" to pkg), "Launching $name.", true)
            }
        }

        if (cleanText.contains("pc mode") || cleanText.contains("desktop mode")) {
            return JarvisCommandResult("SWITCH_PC_MODE", emptyMap(), "Switching to PC Desktop interface.", true)
        }

        return null
    }

    private fun executeOnlineAi(query: String): JarvisCommandResult {
        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey

        val prompt = "You are JARVIS Android assistant. User speech: \"" + query + "\". " +
                "Extract intent as JSON with keys: action (OPEN_APP, AUTO_TOUCH_TEXT, WEB_SEARCH, SPEAK_ONLY), " +
                "params: { target: string }, spokenResponse: string (concise witty 1-2 sentence response). Return raw JSON only."

        val jsonString = "{\"contents\":[{\"parts\":[{\"text\":\"" + prompt.replace(""", "\"") + "\"}]}]}"

        val request = Request.Builder()
            .url(endpoint)
            .post(jsonString.toRequestBody("application/json".toMediaType()))
            .build()

        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                return JarvisCommandResult("SPEAK_ONLY", emptyMap(), "At your command, Sir.", false)
            }
            val body = response.body?.string() ?: ""
            val jsonRoot = gson.fromJson(body, JsonObject::class.java)
            val text = jsonRoot.getAsJsonArray("candidates").get(0).asJsonObject
                .getAsJsonObject("content").getAsJsonArray("parts").get(0).asJsonObject
                .get("text").asString.trim()

            val cleanJson = text.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val parsedObj = gson.fromJson(cleanJson, JsonObject::class.java)

            val action = parsedObj.get("action")?.asString ?: "SPEAK_ONLY"
            val spoken = parsedObj.get("spokenResponse")?.asString ?: "Instruction executed, Sir."
            val params = mutableMapOf<String, String>()
            parsedObj.getAsJsonObject("params")?.entrySet()?.forEach {
                params[it.key] = it.value.asString
            }
            return JarvisCommandResult(action, params, spoken, false)
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
