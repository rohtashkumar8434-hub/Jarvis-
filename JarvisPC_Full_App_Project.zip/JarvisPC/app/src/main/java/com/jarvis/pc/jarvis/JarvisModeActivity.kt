package com.jarvis.pc.jarvis

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.jarvis.pc.R
import com.jarvis.pc.automation.AutoTouchController
import com.jarvis.pc.core.DeviceModeManager
import com.jarvis.pc.pc.PcModeActivity
import com.jarvis.pc.services.FloatingJarvisOverlayService
import com.jarvis.pc.ui.ArcPulseView
import com.jarvis.pc.ui.SetupActivity
import com.jarvis.pc.utils.PermissionHelper
import kotlinx.coroutines.launch

class JarvisModeActivity : AppCompatActivity() {

    private lateinit var arcPulseView: ArcPulseView
    private lateinit var tvStatus: TextView
    private lateinit var tvJarvisSpeech: TextView
    private lateinit var etCommandInput: EditText
    private lateinit var deviceModeManager: DeviceModeManager
    private lateinit var jarvisBrain: JarvisBrain
    private lateinit var actionExecutor: ActionExecutor
    private lateinit var voiceManager: VoiceManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jarvis_mode)

        arcPulseView = findViewById(R.id.arcPulseView)
        tvStatus = findViewById(R.id.tvJarvisStatus)
        tvJarvisSpeech = findViewById(R.id.tvJarvisSpeech)
        etCommandInput = findViewById(R.id.etCommandInput)

        jarvisBrain = JarvisBrain(this)
        actionExecutor = ActionExecutor(this)

        voiceManager = VoiceManager(this, onSpeechRecognized = { speech ->
            tvJarvisSpeech.text = "You: " + speech
            handleCommand(speech)
        }, onListeningState = { listening ->
            arcPulseView.setListening(listening)
            tvStatus.text = if (listening) "JARVIS: LISTENING AUDIO..." else "JARVIS: SYSTEM ONLINE"
        })

        deviceModeManager = DeviceModeManager(this) { isPcMode ->
            if (isPcMode) {
                startActivity(Intent(this, PcModeActivity::class.java))
            }
        }
        deviceModeManager.startListening()

        setupButtons()

        if (intent.getBooleanExtra("EXTRA_START_VOICE", false)) {
            voiceManager.startListening()
        }
    }

    private fun setupButtons() {
        arcPulseView.setOnClickListener { voiceManager.startListening() }

        findViewById<Button>(R.id.btnSendCommand).setOnClickListener {
            val query = etCommandInput.text.toString().trim()
            if (query.isNotBlank()) {
                tvJarvisSpeech.text = "You: " + query
                handleCommand(query)
                etCommandInput.text.clear()
            }
        }

        findViewById<Button>(R.id.chipAutoTouch).setOnClickListener {
            val query = "click search"
            tvJarvisSpeech.text = "Directive: Auto Touch Test"
            handleCommand(query)
        }
        findViewById<Button>(R.id.chipTorch).setOnClickListener { handleCommand("torch on") }
        findViewById<Button>(R.id.chipVolume).setOnClickListener { handleCommand("volume up") }
        findViewById<Button>(R.id.chipPcMode).setOnClickListener {
            startActivity(Intent(this, PcModeActivity::class.java))
        }

        findViewById<Button>(R.id.btnToggleFloatingOverlay).setOnClickListener {
            if (PermissionHelper.hasSystemAlertWindow(this)) {
                startService(Intent(this, FloatingJarvisOverlayService::class.java))
                Toast.makeText(this, "Floating Jarvis HUD launched!", Toast.LENGTH_SHORT).show()
            } else {
                PermissionHelper.openOverlaySettings(this)
            }
        }

        findViewById<Button>(R.id.btnOpenSetup).setOnClickListener {
            startActivity(Intent(this, SetupActivity::class.java))
        }
    }

    private fun handleCommand(cmd: String) {
        lifecycleScope.launch {
            tvStatus.text = "JARVIS: PROCESSING..."
            val result = jarvisBrain.processQuery(cmd)
            actionExecutor.execute(result)
            voiceManager.speak(result.spokenResponse)

            val modeBadge = if (result.isOfflineExecuted) "[OFFLINE ENGINE]" else "[ONLINE AI]"
            tvStatus.text = "JARVIS: " + modeBadge + " COMPLETED"
            tvJarvisSpeech.text = "Jarvis: " + result.spokenResponse
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        deviceModeManager.stopListening()
        voiceManager.destroy()
    }
}
