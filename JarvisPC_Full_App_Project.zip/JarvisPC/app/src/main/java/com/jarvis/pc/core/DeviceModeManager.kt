package com.jarvis.pc.core

import android.content.Context
import android.hardware.input.InputManager
import android.view.InputDevice

/**
 * Monitors hardware input devices (OTG dongle, physical keyboard, mouse).
 * Automatically fires callback when dongle is connected or disconnected.
 */
class DeviceModeManager(
    private val context: Context,
    private val onModeChanged: (isPcMode: Boolean) -> Unit
) {
    private val inputManager = context.getSystemService(Context.INPUT_SERVICE) as InputManager
    private var isCurrentlyPcMode = false

    private val inputListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) {
            checkCurrentDevices()
        }

        override fun onInputDeviceRemoved(deviceId: Int) {
            checkCurrentDevices()
        }

        override fun onInputDeviceChanged(deviceId: Int) {
            checkCurrentDevices()
        }
    }

    fun startListening() {
        inputManager.registerInputDeviceListener(inputListener, null)
        checkCurrentDevices()
    }

    fun stopListening() {
        try {
            inputManager.unregisterInputDeviceListener(inputListener)
        } catch (_: Exception) {}
    }

    fun checkCurrentDevices(): Boolean {
        var keyboardOrMouseConnected = false
        val deviceIds = inputManager.inputDeviceIds

        for (id in deviceIds) {
            val device = inputManager.getInputDevice(id) ?: continue
            val sources = device.sources

            val isKeyboard = (sources and InputDevice.SOURCE_KEYBOARD) == InputDevice.SOURCE_KEYBOARD &&
                    device.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
            val isMouse = (sources and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE

            if (isKeyboard || isMouse) {
                keyboardOrMouseConnected = true
                break
            }
        }

        if (keyboardOrMouseConnected != isCurrentlyPcMode) {
            isCurrentlyPcMode = keyboardOrMouseConnected
            onModeChanged(isCurrentlyPcMode)
        }
        return isCurrentlyPcMode
    }

    fun isPcMode(): Boolean = isCurrentlyPcMode
}
