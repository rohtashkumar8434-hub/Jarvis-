package com.jarvis.pc.pc

import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Build

object FreeformLauncher {

    fun launch(context: Context, packageName: String, bounds: Rect? = null) {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName) ?: return
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)

        val options = ActivityOptions.makeBasic()
        if (bounds != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            options.launchBounds = bounds
        }

        try {
            val method = ActivityOptions::class.java.getMethod("setLaunchWindowingMode", Int::class.javaPrimitiveType)
            method.invoke(options, 5) // WINDOWING_MODE_FREEFORM
        } catch (_: Exception) {}

        context.startActivity(launchIntent, options.toBundle())
    }
}
