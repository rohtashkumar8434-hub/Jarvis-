package com.jarvis.pc

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.pc.core.DeviceModeManager
import com.jarvis.pc.jarvis.JarvisModeActivity
import com.jarvis.pc.pc.PcModeActivity
import com.jarvis.pc.ui.SetupActivity
import com.jarvis.pc.utils.PermissionHelper

class MainActivity : AppCompatActivity() {

    private lateinit var deviceModeManager: DeviceModeManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Check if required permissions are granted
        if (!PermissionHelper.areAllGranted(this)) {
            startActivity(Intent(this, SetupActivity::class.java))
            finish()
            return
        }

        // 2. Check Dongle Connection & Route
        deviceModeManager = DeviceModeManager(this) { isPcMode ->
            routeToMode(isPcMode)
        }
        val isPc = deviceModeManager.checkCurrentDevices()
        routeToMode(isPc)
    }

    private fun routeToMode(isPcMode: Boolean) {
        val target = if (isPcMode) PcModeActivity::class.java else JarvisModeActivity::class.java
        val intent = Intent(this, target).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        }
        startActivity(intent)
        finish()
    }
}
