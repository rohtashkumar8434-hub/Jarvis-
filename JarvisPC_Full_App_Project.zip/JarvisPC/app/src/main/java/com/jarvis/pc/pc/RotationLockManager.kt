package com.jarvis.pc.pc

import android.content.pm.ActivityInfo
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity

class RotationLockManager(private val activity: AppCompatActivity) {

    fun lockToLandscape() {
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        if (Settings.System.canWrite(activity)) {
            try {
                Settings.System.putInt(activity.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            } catch (_: Exception) {}
        }
    }

    fun unlockRotation() {
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (Settings.System.canWrite(activity)) {
            try {
                Settings.System.putInt(activity.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
            } catch (_: Exception) {}
        }
    }
}
