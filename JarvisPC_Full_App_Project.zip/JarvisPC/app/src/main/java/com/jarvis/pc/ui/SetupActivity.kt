package com.jarvis.pc.ui

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.jarvis.pc.MainActivity
import com.jarvis.pc.R
import com.jarvis.pc.utils.PermissionHelper

class SetupActivity : AppCompatActivity() {

    private lateinit var tvStatusAccessibility: TextView
    private lateinit var tvStatusOverlay: TextView
    private lateinit var tvStatusWrite: TextView
    private lateinit var tvStatusAudio: TextView
    private lateinit var btnContinue: Button

    private val audioLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { updateStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)

        tvStatusAccessibility = findViewById(R.id.tvStatusAccessibility)
        tvStatusOverlay = findViewById(R.id.tvStatusOverlay)
        tvStatusWrite = findViewById(R.id.tvStatusWrite)
        tvStatusAudio = findViewById(R.id.tvStatusAudio)
        btnContinue = findViewById(R.id.btnContinue)

        findViewById<Button>(R.id.btnGrantAccessibility).setOnClickListener {
            PermissionHelper.openAccessibilitySettings(this)
        }
        findViewById<Button>(R.id.btnGrantOverlay).setOnClickListener {
            PermissionHelper.openOverlaySettings(this)
        }
        findViewById<Button>(R.id.btnGrantWrite).setOnClickListener {
            PermissionHelper.openWriteSettings(this)
        }
        findViewById<Button>(R.id.btnGrantAudio).setOnClickListener {
            audioLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        btnContinue.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        tvStatusAccessibility.text = if (PermissionHelper.hasAccessibilityService()) "Accessibility: ACTIVE [✓]" else "Accessibility: DISABLED [✗]"
        tvStatusOverlay.text = if (PermissionHelper.hasSystemAlertWindow(this)) "Overlay: GRANTED [✓]" else "Overlay: MISSING [✗]"
        tvStatusWrite.text = if (PermissionHelper.hasWriteSettings(this)) "Write Settings: GRANTED [✓]" else "Write Settings: MISSING [✗]"
        tvStatusAudio.text = if (PermissionHelper.hasRecordAudio(this)) "Audio: GRANTED [✓]" else "Audio: MISSING [✗]"
    }
}
