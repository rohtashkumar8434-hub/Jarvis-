#!/bin/bash
echo "=========================================="
echo "  Building JarvisPC Android APK..."
echo "=========================================="
if [ -f "./gradlew" ]; then
    ./gradlew assembleDebug
else
    gradle assembleDebug
fi
echo "Build finished! APK generated in app/build/outputs/apk/debug/"
