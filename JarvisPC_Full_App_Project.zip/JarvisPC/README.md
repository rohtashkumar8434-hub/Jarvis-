# 🤖 JarvisPC - Hybrid Android OS & AI Voice Assistant App

**JarvisPC** ek unique aur powerful dual-mode Android app hai jo aapke smartphone ko ek versatile computing device me badal deta hai:
1. 🔌 **PC Desktop Mode (Dongle Connected)**: Jab aap USB-C / OTG se keyboard/mouse dongle connect karte hain, to app instant PC Desktop interface (Windows 11 style Taskbar, Start Menu, Floating Freeform Multi-Windows, Physical Keyboard Shortcuts jaise Win+E, Alt+Tab, and Landscape Rotation Lock) me convert ho jata hai.
2. 🎙️ **Jarvis AI Assistant Mode (Dongle Removed)**: Jab dongle disconnected hota hai, to app ek futuristic Holographic HUD ke sath active voice AI ban jata hai.
3. 👆 **Automatic Touch Control (Extra Requested Feature)**: Android AccessibilityService gestures ke zariye automatic touch simulation (screen tap, swipe, auto-scroll, aur on-screen text matching jaise "click search") support karta hai.
4. ⚡ **Hybrid Online + Offline AI Engine (Extra Requested Feature)**:
   - **Offline Engine (0ms Latency, No Internet Required)**: Volume up/down, mute, flashlight/torch on-off, app launches, screen navigation (Home/Back/Recents), auto-touch gestures, and screenshot capture bina internet ke turant execute hote hain.
   - **Online AI Engine**: Google Gemini API se connect hokar natural language conversational reasoning, dynamic command parsing, aur intelligent response provide karta hai.

---

## 📁 Project Architecture & Components

```
JarvisPC/
├── app/
│   ├── src/main/
│   │   ├── java/com/jarvis/pc/
│   │   │   ├── JarvisApp.kt                          // Application singleton
│   │   │   ├── MainActivity.kt                       // Master Router & Permission Check
│   │   │   ├── core/
│   │   │   │   └── DeviceModeManager.kt              // Hardware Dongle / InputDevice Listener
│   │   │   ├── automation/
│   │   │   │   └── AutoTouchController.kt            // Automatic Touch Simulation (Tap, Swipe, ClickByText)
│   │   │   ├── services/
│   │   │   │   ├── JarvisAccessibilityService.kt     // Hardware Key Interception (Win+E, Alt+Tab) & Gestures
│   │   │   │   └── FloatingJarvisOverlayService.kt   // Floating Holographic HUD Widget
│   │   │   ├── jarvis/
│   │   │   │   ├── JarvisBrain.kt                    // Hybrid AI Engine (Offline Rules + Online Gemini)
│   │   │   │   ├── ActionExecutor.kt                 // Executes device actions & automation
│   │   │   │   ├── VoiceManager.kt                   // SpeechRecognizer (STT) + TextToSpeech (TTS)
│   │   │   │   └── JarvisModeActivity.kt             // Futuristic Hologram HUD Activity
│   │   │   ├── pc/
│   │   │   │   ├── PcModeActivity.kt                 // Desktop Workspace, Taskbar, Start Menu
│   │   │   │   ├── FreeformLauncher.kt               // Multi-window Freeform App Launcher
│   │   │   │   └── RotationLockManager.kt            // Landscape Orientation Lock
│   │   │   ├── ui/
│   │   │   │   ├── ArcPulseView.kt                   // Custom Canvas Animated Sci-Fi Arc HUD
│   │   │   │   └── SetupActivity.kt                  // Step-by-Step Permissions Wizard
│   │   │   └── utils/
│   │   │       └── PermissionHelper.kt               // Permissions verification utility
│   │   ├── res/
│   │   │   ├── layout/                               // All XML UI layouts
│   │   │   ├── values/                               // Strings, Colors (Cyan Neon, Dark Sci-Fi), Themes
│   │   │   └── xml/accessibility_config.xml          // Accessibility configuration
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── build_apk.sh                                      // 1-Click Linux/Mac APK Build Script
├── build_apk.bat                                     // 1-Click Windows APK Build Script
├── settings.gradle.kts
└── README.md
```

---

## 🚀 1-Click APK Build Instructions

### Method 1: Android Studio (Recommended)
1. Is ZIP file ko extract karein.
2. **Android Studio** open karein -> **Open** -> `JarvisPC` folder select karein.
3. Gradle sync complete hone dein.
4. Top menu me **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)** par click karein.
5. Android Studio kuch hi seconds me debug APK generate kar dega (`app/build/outputs/apk/debug/app-debug.apk`).
6. APK ko apne phone me install karein!

### Method 2: Command Line / Terminal (Without opening IDE)
- **Windows**: `build_apk.bat` par double-click karein ya terminal me `gradlew assembleDebug` run karein.
- **Mac / Linux**: Terminal me `./gradlew assembleDebug` run karein.

---

## ⚙️ Initial Phone Setup & Permissions

App install karne ke baad pehli baar chalane par **Setup Wizard** aayega:
1. **Accessibility Service**: Enable karein -> "JarvisPC" ko activate karein (isse Keyboard shortcuts aur Auto-Touch gestures enable hote hain).
2. **Display over other apps (Overlay)**: Enable karein (isse Floating HUD aur Taskbar overlay chalega).
3. **Modify System Settings**: Enable karein (Landscape rotation lock ke liye).
4. **Microphone (Audio)**: Allow karein (Voice recognition ke liye).

### Freeform Windows Enable karna (For PC Mode):
Android 7.0 se 14+ me kisi bhi phone par freeform multi-window chalane ke liye:
- Phone ke **Settings** -> **Developer Options** me jayein.
- **"Force activities to be resizable"** aur **"Enable freeform windows"** ko ON karein.
- Phone restart karein.
- (Alternative via ADB): `adb shell settings put global enable_freeform_support 1`

---

## 💡 How to Use

- **Dongle Plugged In**: Phone me keyboard/mouse dongle lagate hi screen landscape desktop ban jayegi. Taskbar par Start button se apps khol sakte hain aur Win+E, Win+D, Alt+Tab shortcuts chala sakte hain.
- **Dongle Unplugged**: Phone seedha Jarvis Voice HUD me chala jayega. Glowing core par tap karein ya bol kar command dein.
- **Offline Commands**:
  - *"Torch on"* / *"Torch off"*
  - *"Volume up"* / *"Volume down"* / *"Mute"*
  - *"Scroll down"* / *"Scroll up"*
  - *"Open YouTube"* / *"Open WhatsApp"* / *"Open Chrome"*
  - *"Go home"* / *"Recent apps"* / *"Take screenshot"*
  - *"Click search"* (Automatic Touch on screen button)
- **Online Commands**: Gemini API key daalne par kisi bhi natural sawal ka jawab aur complex planning Jarvis execute karega.
