@echo off
echo ==========================================
echo   Building JarvisPC Android APK...
echo ==========================================
if exist gradlew.bat (
    call gradlew.bat assembleDebug
) else (
    call gradle assembleDebug
)
echo Build finished! APK generated in app\build\outputs\apk\debug\
pause
